#Autor: Yuliia Melnyk

# Module that implements methods for searching zeros of given function
module ZeroModule
    include("./zad1/zad1.jl")
    include("./zad2/zad2.jl")
    include("./zad3/zad3.jl")

    export mbisekcji, mstycznych, msiecznych
end